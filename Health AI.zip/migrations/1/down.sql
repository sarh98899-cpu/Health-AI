
DROP INDEX idx_preventive_plans_user_id;
DROP INDEX idx_consultations_user_id;
DROP INDEX idx_medical_tests_user_id;
DROP INDEX idx_health_profiles_user_id;
DROP TABLE preventive_plans;
DROP TABLE consultations;
DROP TABLE medical_tests;
DROP TABLE health_profiles;
